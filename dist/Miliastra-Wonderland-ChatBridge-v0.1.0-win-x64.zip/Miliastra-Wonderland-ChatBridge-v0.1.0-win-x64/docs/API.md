# 聊天 API 接口文档

> 版本：v1  
> 端口：**18889**（BOT 端口 + 1）  
> 协议：HTTP + WebSocket  
> 消费者：Miliastra-Wonderland-Music（下称"BOT"）

---

## 0. 这个 API 做什么

从原神客户端实时抓取**千星奇域**聊天消息，转成结构化 JSON 推送给 BOT。
BOT 用它替代 OCR 的聊天内容识别，只保留界面识别。

**数据来源**：注入游戏的 DLL 通过命名管道回传网络包，本服务解析 protobuf。

---

## 1. 鉴权

### 1.1 Token 来源

从 BOT 的 `config.yaml` 读取：

```yaml
http:
  access_token: "<token>"
```

- 若该字段为空，BOT 首次启动时会自动生成随机 UUID 并写回
- 若该字段是默认值 `miliastra-default-access-token`，**本服务拒绝启动**并报错

### 1.2 传递方式

所有请求（含 WS）必须带请求头：

```
x-miliastra-token: <token>
```

- 不支持 `Authorization: Bearer`
- 缺失或错误 → `401`
- 常数时间比较，防时序攻击

---

## 2. 数据模型

### 2.1 ChatMessage

```json
{
  "id": 1,
  "ts": 1792772291,
  "channel": "current_hall",
  "hallId": 1159597756390572032,
  "hallType": 16,
  "from": { "uid": 127138439, "name": "2#BOT|勿加" },
  "to": 127138439,
  "text": "123321"
}
```

| 字段 | 类型 | 必有 | 说明 |
|---|---|---|---|
| `id` | number | ✅ | **进程内自增序号**，从 1 开始。重启归零，不跨进程唯一 |
| `ts` | number | ✅ | Unix 时间戳，**秒级**。同秒多条会重复，不能当排序键 |
| `channel` | string | ✅ | `"current_hall"` \| `"private"` |
| `hallId` | number \| null | ✅ | 大厅 ID（64 位整数）。`private` 时为 `null` |
| `hallType` | number \| null | ✅ | 大厅类型（实测 16 / 23）。`private` 时为 `null` |
| `from.uid` | number | ✅ | 发送者 UID（原神账号 ID，uint32） |
| `from.name` | string \| null | ✅ | 发送者昵称。**可能为 null**（昵称异步解析，见 §5） |
| `to` | number \| null | ✅ | 接收者 UID。大厅广播为 `null` |
| `text` | string | ✅ | 消息正文，UTF-8 原文（全角/emoji 原样） |

**注意：`id` 是进程内序号，不是游戏消息 ID。** 用途仅为同一次运行内去重与排序。

### 2.2 不推送的数据（明确排除）

| 数据 | 原因 |
|---|---|
| `public_channel`（跨厅公共频道） | BOT 只处理当前大厅 |
| 表情消息（`#1448`） | 不可能是命令 |
| 附件/系统消息 | 不可能是命令 |
| 大厅内序号 `#6` | 重进大厅会重置，不可靠 |
| 身份码 `#4`（成员/厅主） | 不稳定，BOT 用身份映射判断权限 |
| 引用/回复信息 | 当前不需要 |
| 大厅容量/人数 | 当前不需要 |
| 原始抓包文件引用 | 内部实现细节 |

---

## 3. 接口

### 3.1 `GET /health`

存活检查 + 当前状态。

**响应 200**：

```json
{
  "ok": true,
  "version": "0.1.0",
  "uptimeSec": 3600,
  "gameConnected": true,
  "currentHall": { "id": 1159597756390572032, "type": 16 },
  "lastMessageId": 42,
  "subscribers": 1
}
```

| 字段 | 说明 |
|---|---|
| `gameConnected` | 是否已成功注入并保持管道连接 |
| `currentHall` | 当前判定的大厅；未判定时为 `null` |
| `lastMessageId` | 已推送的最大 `id`；无消息时为 `0` |
| `subscribers` | 当前 WS 订阅者数量 |

**用途**：BOT 启动时用它判断是否可用；运行中定期轮询判断连接健康。

---

### 3.2 `WS /stream`

实时消息推送。**这是主接口。**

**连接**：

```
ws://127.0.0.1:18889/stream
x-miliastra-token: <token>
```

> 浏览器 WS API 无法设置自定义头。若需从浏览器连接，额外支持 query 参数 `?token=<token>`。BOT 是原生客户端，用请求头即可。

**服务端 → 客户端消息**

连接成功后推送的第一条是握手：

```json
{ "type": "hello", "version": "0.1.0", "lastMessageId": 42 }
```

之后每条聊天消息：

```json
{ "type": "message", "message": { ...ChatMessage... } }
```

大厅切换时推送：

```json
{ "type": "hall_changed", "hallId": 7699842546315381217, "hallType": 23 }
```

**心跳**：服务端每 30 秒发一次 WS Ping 帧。客户端应在 10 秒内回 Pong（多数 WS 库自动处理）。

**客户端 → 服务端**

当前**不需要**客户端发送任何数据。发来的文本帧会被忽略。

**断线重连**：

1. 重新连接 `/stream`
2. 读握手里的 `lastMessageId`
3. 如需补齐断线期间的消息，调用 `GET /messages?since=<本地最后id>`

---

### 3.3 `GET /messages?since=<id>&limit=<n>`

**补拉**断线期间的消息。服务端维护一个内存环形缓冲。

**参数**：

| 参数 | 必填 | 默认 | 说明 |
|---|---|---|---|
| `since` | ❌ | 0 | 只返回 `id > since` 的消息 |
| `limit` | ❌ | 200 | 最多返回条数，上限 1000 |

**响应 200**：

```json
{
  "messages": [ { ...ChatMessage... } ],
  "lastMessageId": 42,
  "truncated": false
}
```

| 字段 | 说明 |
|---|---|
| `messages` | 按 `id` 升序 |
| `lastMessageId` | 服务端当前最大 `id` |
| `truncated` | `true` 表示请求的区间超出缓冲范围，可能有遗漏 |

**缓冲策略**：保留最近 **2000 条**。超出部分丢弃，且 `truncated` 为 `true`。

---

### 3.4 `GET /names?uids=1,2,3`

批量查询昵称。用于补全 `from.name` 为 `null` 的情况。

**参数**：

| 参数 | 必填 | 说明 |
|---|---|---|
| `uids` | ✅ | 逗号分隔的 UID 列表，最多 100 个 |

**响应 200**：

```json
{
  "names": {
    "127138439": "2#BOT|勿加",
    "195650027": null
  }
}
```

- 已解析 → 昵称字符串
- 尚未解析 → `null`
- 未查询过该 UID → 不出现在结果里

---

## 4. 错误响应

所有错误统一格式：

```json
{ "error": { "code": "unauthorized", "message": "invalid or missing x-miliastra-token" } }
```

| HTTP | code | 场景 |
|---|---|---|
| 400 | `bad_request` | 参数格式错误（如 `since` 不是数字） |
| 401 | `unauthorized` | token 缺失或错误 |
| 404 | `not_found` | 路径不存在 |
| 503 | `game_not_connected` | 游戏未运行 / 注入失败（仅 `/messages` 与 `/names` 会返回，`/health` 永远 200） |

---

## 5. 昵称解析的不确定性

**这是本 API 最重要的限制，BOT 侧必须正确处理。**

聊天包里**只有 UID**，昵称来自游戏的资料包（cmd 584/4410/24809），到达时序不确定：

| 情况 | 表现 |
|---|---|
| 昵称先于消息到达 | `from.name` 有值 ✅ |
| 昵称晚于消息到达 | 该条消息 `from.name` 为 `null`，**服务端不会补发** |
| 昵称始终未到达 | 永久为 `null` |

**BOT 侧应对**：

1. **优先按 UID 匹配身份**（后续 BOT 会改为 UID 优先的身份映射）
2. 拿到 `null` 时调 `GET /names?uids=` 查询
3. 仍为 `null` 时，按"未知发送者"处理 —— **不授权任何权限**

---

## 6. 当前大厅的判定

`channel=current_hall` 的消息来自"BOT 所在大厅"。判定依赖两个信号：

1. **BOT 自己发出的大厅消息**的 `hallId` —— 最可靠
2. **大厅人数包（7154）**里的 `hallId` —— 补充

**已知限制**：

- BOT 长时间不说话时，若也没有人数包下发，当前大厅可能判定不出来
- 判定失败时，大厅消息会被归为公共频道并被**丢弃**（不推送）

**切换时**会推送 `hall_changed` 事件。BOT 应据此重置大厅相关的临时状态。

---

## 7. 启动与配置

### 7.1 配置来源

启动参数：

```
Miliastra-Wonderland-ChatBridge.exe [--config <path-to-bot-config.yaml>]
```

- `--config` 省略时，默认在 `../Miliastra-Wonderland-Music/config.yaml` 查找
- 从该 yaml 读取 `http.port`（作为端口基数）与 `http.access_token`

### 7.2 端口

```
本服务端口 = config.yaml 的 http.port + 1
```

默认 BOT 端口 18888 → 本服务 **18889**。

### 7.3 启动前置条件

| 条件 | 不满足时 |
|---|---|
| 配置文件可读 | 拒绝启动，报错 |
| `access_token` 非空 | 拒绝启动 |
| `access_token` ≠ 默认值 | 拒绝启动（提示用户修改） |

---

## 8. 完整交互示例

```text
1. BOT 启动 → GET /health
   → { "ok": true, "gameConnected": true, "currentHall": {...} }

2. BOT 连接 WS → ws://127.0.0.1:18889/stream (x-miliastra-token: xxx)
   ← { "type": "hello", "lastMessageId": 40 }

3. 玩家在大厅发 "@点歌 晴天"
   ← { "type": "message", "message": {
        "id": 41, "ts": 1792772291, "channel": "current_hall",
        "hallId": 1159597756390572032, "hallType": 16,
        "from": { "uid": 346724821, "name": "荧" },
        "to": null, "text": "@点歌 晴天"
      } }

4. BOT 发现 from.name 为 null 的另一条消息
   → GET /names?uids=195650027
   ← { "names": { "195650027": "吾妻之芙芙" } }

5. WS 意外断开
   → 重连 → ← hello(lastMessageId: 42)
   → GET /messages?since=41
   ← { "messages": [ {id:42, ...} ], "lastMessageId": 42 }
```

---

## 9. 与 BOT 侧的契约总结

| 事项 | 约定 |
|---|---|
| 去重 | BOT 按 `id` 去重（进程内） |
| 排序 | BOT 按 `id` 排序，**不用 `ts`** |
| 昵称缺失 | `from.name=null` 是正常情况，BOT 用 `/names` 补查或按 UID 匹配 |
| 权限 | 发送者无法确认时（name 与 uid 都查不到身份），**不授权** |
| 大厅切换 | 收到 `hall_changed` 需重置大厅相关状态 |
| 重连 | 重连后先 hello 再决定是否用 `/messages` 补拉 |
