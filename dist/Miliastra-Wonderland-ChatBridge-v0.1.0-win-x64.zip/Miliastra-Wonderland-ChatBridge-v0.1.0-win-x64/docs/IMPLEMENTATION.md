# 实现约束（改动前必读）

每条都对应一次真实故障。绕过其中任何一条都会重现。

---

## 1. 游戏钩子绝不能等待管道

**这条最重要，曾经导致好友列表加载异常。**

钩子 `OnToInt32` 运行在游戏的**网络解包线程**里。任何阻塞都会直接拖慢游戏：
好友列表、世界切换、大厅加载全都受影响。

改前的写法（错误）：

```csharp
// 钩子线程里直接写管道并同步等回执
_pipeWriter.Write(...);
if (_pipeReader.ReadBoolean()) { ... }   // 宿主 50ms 轮询 → 最坏等 50ms+
```

改后的写法：

```csharp
// 钩子：只复制入队，立即返回
PacketOutbox.Enqueue(cmdId, data.ToArray());

// 后台线程 mwc-packet-sender：写管道 + 读回执，整体 500ms 超时
```

**约束**：
- 队列**有界**（256），满时丢弃这份副本。丢几条聊天远比卡住游戏划算。
- 超时覆盖"写 + 读回执"整体，不是分别计。
- 超时后 `Disable()`：标记停用 + 完成队列 + 关闭管道，钩子此后只透传原始返回值。
- 绝不能把回执读取留在钩子线程上——迟到的回执会让协议错位。

---

## 2. 只能自己拉起游戏，不能附加

原神反作弊会拦截外部进程对游戏内存的写入。实测：

```
对游戏进程：OpenProcess 各种权限都成功，VirtualAllocEx 一律 FAIL err=5
对普通进程：OpenProcess + VirtualAllocEx 全部成功
```

`CreateProcessW(CREATE_SUSPENDED)` 返回的是"创建者句柄"，不受该拦截。
所以启动前必须确认游戏没在运行，否则会拉出第二个实例。

---

## 3. 必须等 LoadLibraryW 线程真正结束

`LoadLibraryW` 的远程线程在 DllMain 里持有 **loader lock**。NativeAOT 初始化要几秒。
过早继续并恢复主线程，主线程会阻塞在 loader lock 上——症状是"进程活着但 CPU 不涨、窗口不出现"。

```rust
let waited = unsafe { WaitForSingleObject(thread, 30_000) };
```

---

## 4. Session 0 / Session 1

- SSH 登录的进程在 **Session 0**（服务会话，无桌面）
- 游戏窗口必须在 **Session 1**

在 Session 0 启动的游戏会正常跑（CPU 涨）但**永远没有窗口**。

必须用计划任务 + `-LogonType Interactive` 启动，并确认 `Get-Process YuanShen` 的 `SessionId = 1`。

---

## 5. 子进程窗口会继承父进程的隐藏状态

本程序以隐藏窗口启动。`STARTUPINFO.dwFlags` 不含 `STARTF_USESHOWWINDOW` 时，
子进程用 `SW_SHOWDEFAULT`，会继承隐藏状态。

```rust
si.dwFlags = STARTF_USESHOWWINDOW;
si.wShowWindow = SW_SHOWNORMAL;          // = 1
si.lpDesktop = "WinSta0\\Default";
```

---

## 6. 管道协议：漏一个分支就卡死

DLL 在 0x03/0x04/0xFF 之后都**等一个 bool 回执**。漏读或少读会让流永久错位，
DLL 卡在等回执，游戏主线程随之卡住。

| 类型 | 载荷 | 宿主应答 |
|---|---|---|
| 0x03 | i32 type + f64 value (12B) | 1 字节 bool |
| 0x04 | u16 cmd + u32 len + payload | 1 字节 bool |
| 0xFA | 无 | u32 cmdId 列表 + `u32::MAX` |
| 0xFB | 无 | u32 prop 列表 + `u32::MAX` |
| 0xFD | 无 | 10 个 u32 RVA |
| 0xFE | 无 | 无 |
| 0xFF | 无 | 1 字节 bool |

**必须做**：未知类型 → 终止会话；载荷长度上限 1 MiB（错位后会读到天文数字）。

---

## 7. 不要用 PIPE_NOWAIT

该模式已废弃，且会让 `ConnectNamedPipe`/`ReadFile` 的返回语义不可靠
（实测会读到假的 EOF，服务在 2ms 内误判对端关闭）。用阻塞管道 + `PeekNamedPipe` 探测。

---

## 8. 当前大厅：跟随消息流，不信 7154

`7154`（大厅人数）只给 `hall_id` 和人数，**切换大厅后不会立刻重发**。
拿它当过滤条件会把新大厅的消息全部误丢。

- `hall_type == 23` → 公共频道，抓取但**不推送**
- `hall_type == 16` → 当前大厅，推送
- 私聊（`hall = None`）→ 推送

公共频道过滤必须在更新 `current_hall` **之前**，否则自己在公共频道发言会污染大厅状态。

---

## 9. 日志不能打印 payload

`Frame::Packet` 的 Debug 会把整段 payload 格式化成文本。每帧几 KB 的格式化 + 写盘
足以把吞吐拖死。只记帧类型和长度。

---

## 10. 判定"游戏卡住"只能看 CPU

从 SSH（Session 0）用 `EnumWindows`/`MainWindowHandle` 检查窗口是**假阴性**——
枚举不到 Session 1 的窗口。采样两次 CPU：8 秒涨几秒正常，涨 0.1 就是卡住。

`CREATE_SUSPENDED` 状态的特征是 `threads=3, cpu=0`。

---

## 11. 停机顺序

游戏内 DLL 在管道断开时会抛 `Pipe is broken`，其异常处理器弹 MessageBox，
点确定后 `Environment.Exit(-1)` **退出游戏**。

更新本程序前必须先让玩家正常退出游戏。

---

## 12. PowerShell 脚本必须纯 ASCII

Windows PowerShell 5.1 按 ANSI 读 `.ps1`，中文会变乱码并破坏引号匹配，
报 `The string is missing the terminator`。

---

## 13. 为什么不用独立读线程（试过，失败）

试过用 `File::try_clone()` 复制管道句柄 + 独立读线程替代轮询，结果握手卡死：
游戏停在 `CREATE_SUSPENDED`（`cpu=0 threads=3`），DLL 的 `0xFA` 发不出来。
原因未查清（怀疑 `DuplicateHandle` 后管道句柄的读行为），已回退到
`PeekNamedPipe` 轮询。

**影响有限**：因为 DLL 已异步，宿主轮询延迟不再阻塞游戏线程，只影响回执延迟。
