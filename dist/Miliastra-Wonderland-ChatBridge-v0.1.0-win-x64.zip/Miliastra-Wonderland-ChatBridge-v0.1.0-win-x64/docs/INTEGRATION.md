# 对接说明（给 BOT 侧开发者）

> 配套文档：[API.md](./API.md)  
> 本文只讲**如何消费这个 API**，不涉及数据是怎么抓来的。

---

## 1. 最小可用接入

### 1.1 需要改什么

BOT 侧要新增一个"外部聊天源"，做三件事：

1. 连 `ws://127.0.0.1:18889/stream`，带 `x-miliastra-token`
2. 把收到的 `message` 转成 BOT 内部的聊天消息结构
3. 发布到 `ChatTimeline`

### 1.2 不要做什么

| 反模式 | 为什么不行 |
|---|---|
| 直接调 `ChatTimeline::publish()` | 它会写 `prev` 对齐基准，外部消息没有屏幕坐标，会毒化下一帧真实 OCR 的对齐 |
| 用 `ts` 排序或去重 | 秒级精度，同秒多条会乱序/误判重复 |
| 把外部消息当成"屏幕上的气泡" | 它没有位置，进不了命令锁的 y 容差匹配 |
| 收到 `from.name=null` 就丢弃消息 | 昵称异步到达是常态，应改用 UID 或补查 |

---

## 2. 建议的接入结构

```
src/
  runtime/
    chat_source/
      mod.rs          # trait ChatSource
      ws.rs           # WebSocket 实现
  composition/application/
    external_chat.rs  # 线程：拉消息 → 调 inject_external
```

### 2.1 trait 定义（扩展点）

```rust
/// 外部聊天数据源。将来接 SSE / 长轮询 / 其他游戏只需新增实现。
#[async_trait]
pub trait ChatSource: Send + Sync {
    fn name(&self) -> &str;

    /// 拉取下一批消息。返回 None 表示连接结束。
    async fn next_batch(&mut self) -> Result<Option<Vec<ExternalChatMessage>>>;
}
```

### 2.2 消息结构

```rust
pub struct ExternalChatMessage {
    /// 进程内序号，用于去重与排序
    pub id: u64,
    /// Unix 秒；仅作展示，不参与排序
    pub ts: u64,
    pub channel: ChatChannel,       // CurrentHall | Private
    pub hall_id: Option<u64>,
    pub hall_type: Option<u32>,
    pub from_uid: u32,
    pub from_name: Option<String>,  // 可能为 None，见 §4
    pub to_uid: Option<u32>,
    pub text: String,
}
```

### 2.3 注入入口

**必须新增** `ChatTimeline::inject_external()`，**不要复用** `publish()`：

```rust
impl ChatTimeline {
    /// 外部消息注入：跳过气泡对齐，只进业务账本与订阅队列。
    pub(crate) fn inject_external(
        &self,
        captured_at: Instant,
        epoch: VisualSessionId,        // 保留值，不与 OCR 的 session 冲突
        messages: Vec<ExternalChatMessage>,
    ) -> Result<Vec<ObservedChatMessageId>>;
}
```

**实现要点**：

- 复用 `publish()` 的账本段（`business_pending` / `business_claimed` / `command_locks` / 订阅队列）
- **跳过** `Tracker::observe`（不写 `prev`）与 `state.latest` 写入
- 消息 ID 用**保留的 VisualSessionId**（如 `u64::MAX`），避免与 OCR 的 `next_session` 冲突
- 坐标用哨兵值（若有 `Rect` 字段：`Rect::new(0, i32::MIN/2, 1, 1)`），**永不命中命令锁的 `y <= entry.y + 28`**

---

## 3. 接管 OCR 的开关

### 3.1 停什么、留什么

| 阶段 | 接管后 |
|---|---|
| 取帧 | ✅ 保留 |
| `passive_layout`（模板匹配判 Primary/Secondary/NoChat） | ✅ **必须保留** |
| 变化指纹 / `scan_gate` | ⏸ 可停 |
| `recognize_prepared_chat` / `recognize_passive_secondary` | ⏹ **停** |

在 `shared_observer.rs` 的 `publish` 调用前，把 `messages` 换成空 `Vec`：

```rust
let messages = if external_source_active() {
    Vec::new()   // 不要用 publish_no_chat，那会清 tracker、置 cold_baseline_consumed
} else {
    recognize_prepared_chat(...)?
};
timeline.publish(frame.captured_at, identity, messages)?;
```

### 3.2 切换时的四条重置（缺一不可）

1. `note_baseline` 用**不含"千星/大厅"**的 reason（否则得到 `HallWorldSwitch` 语义，蓝色判新 = 重放历史）
2. 清受影响 chat 的 `command_locks`
3. 递增 epoch，丢弃在途 OCR 回包
4. `chat_baseline_primed = false`

---

## 4. 昵称缺失的处理

`from.name` 为 `null` 是**正常情况**，不是错误。

### 推荐顺序

```
1. from.name 有值 → 用它
2. from.name 为 null → 调 GET /names?uids=<from.uid>
3. 仍为 null → 按"未知发送者"处理，不授权任何权限
```

### 为什么不在服务端等待昵称

昵称来自独立资料包，可能永远不到。阻塞等待会让命令延迟执行，违背实时性目标。

---

## 5. 断线重连

```
WS 断开
  → 重连 ws://127.0.0.1:18889/stream
  ← { "type": "hello", "lastMessageId": 42 }
  → GET /messages?since=<本地最后处理的 id>
  ← { "messages": [...], "lastMessageId": 42, "truncated": false }
```

- `truncated=true` 表示缓冲不够，中间有遗漏 → 建议**清空本地状态、重新建立基线**
- 重连后应做一次与"切换数据源"相同的状态重置

---

## 6. 大厅切换

收到 `hall_changed` 事件时：

```json
{ "type": "hall_changed", "hallId": 7699842546315381217, "hallType": 23 }
```

BOT 应：

1. 重置与该大厅绑定的临时状态（如果有人在大厅模式里）
2. 记录新 `hallId`（用于日志与调试）

**注意**：切换判定可能有延迟（依赖 BOT 自己发言或人数包），不是精确到秒的。

---

## 7. 测试建议

因为没有真实游戏环境时无法验证完整链路，建议分层测试：

| 层级 | 方法 |
|---|---|
| 协议解析 | 用 `/root/DSH/Genshin/artifacts/chat-min.jsonl` 的真实样本做单测 |
| WS 客户端 | 用 mock server 推预设消息，验证重连/补拉 |
| 注入逻辑 | 直接构造 `ExternalChatMessage` 调 `inject_external`，断言 `is_new` 与命令派发 |
| 端到端 | **必须 Windows + 真实游戏**，无法在 Linux 验证 |

---

## 8. 已知风险

| 风险 | 影响 |
|---|---|
| 游戏更新导致字段号变化 | 解析失败，需更新 metadata |
| DLL 无签名 | 供应链风险（固定哈希校验或本地构建） |
| 注入违反 ToS | 封号风险，仅测试账号 |
| 大厅判定不准 | 可能漏消息或误判频道 |
