# Miliastra-Wonderland-ChatBridge launcher
# Requires: Genshin must NOT be running (anti-cheat blocks injection into a live process).
param(
    [string]$Config = "",
    [int]$SelfUid = 0
)
$ErrorActionPreference = 'Stop'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $Config) { $Config = Join-Path $dir 'config.yaml' }
if (-not (Test-Path $Config)) { Write-Host 'config.yaml not found. Copy config.example.yaml first.'; exit 1 }
if ($SelfUid -le 0) { Write-Host 'Usage: .\start.ps1 -SelfUid <your_game_uid>'; exit 1 }
$existing = Get-Process miliastra-wonderland-chatbridge -ErrorAction SilentlyContinue
if ($existing) { Write-Host "already running (pid=$($existing.Id -join ','))"; exit 0 }
$game = Get-Process YuanShen -ErrorAction SilentlyContinue
if ($game) { Write-Host 'Genshin already running. Exit the game first.'; exit 1 }
Start-Process -FilePath (Join-Path $dir 'miliastra-wonderland-chatbridge.exe') -ArgumentList "--config `"$Config`" --self-uid $SelfUid" -WorkingDirectory $dir -WindowStyle Hidden
Write-Host 'started, launching Genshin...'
